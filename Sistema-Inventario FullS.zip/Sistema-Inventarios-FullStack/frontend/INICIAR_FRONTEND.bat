@echo off
set "NPM=npm.cmd"
where npm.cmd >nul 2>&1
if errorlevel 1 (
    set "NODE_DIR=C:\Program Files\Microsoft Visual Studio\2022\Community\MSBuild\Microsoft\VisualStudio\NodeJs"
    set "NPM=C:\Program Files\Microsoft Visual Studio\2022\Community\MSBuild\Microsoft\VisualStudio\NodeJs\npm.cmd"
    set "PATH=C:\Program Files\Microsoft Visual Studio\2022\Community\MSBuild\Microsoft\VisualStudio\NodeJs;%PATH%"
)
if not exist node_modules call "%NPM%" install
call "%NPM%" start
