import { Routes } from '@angular/router';
import { authGuard, adminGuard } from './guards/auth.guard';
import { LoginComponent } from './components/login.component';
import { LayoutComponent } from './components/layout.component';
import { DashboardComponent } from './components/dashboard.component';
import { ProductsComponent } from './components/products.component';
import { ProductFormComponent } from './components/product-form.component';
import { CategoriesComponent } from './components/categories.component';
import { MovementsComponent } from './components/movements.component';

export const routes: Routes = [
  { path: 'login', component: LoginComponent },
  {
    path: '', component: LayoutComponent, canActivate: [authGuard], children: [
      { path: 'inicio', component: DashboardComponent },
      { path: 'productos', component: ProductsComponent },
      { path: 'productos/nuevo', component: ProductFormComponent, canActivate: [adminGuard] },
      { path: 'productos/editar/:id', component: ProductFormComponent, canActivate: [adminGuard] },
      { path: 'categorias', component: CategoriesComponent, canActivate: [adminGuard] },
      { path: 'movimientos', component: MovementsComponent },
      { path: '', pathMatch: 'full', redirectTo: 'inicio' }
    ]
  },
  { path: '**', redirectTo: '' }
];
