export interface UserSession { username: string; role: 'ADMINISTRADOR' | 'EMPLEADO'; }
export interface Category { id?: number; name: string; description: string; }
export interface Product {
  id?: number; code: string; name: string; description: string; category: Category;
  purchasePrice: number; salePrice: number; quantity: number; minimumStock: number;
  supplier: string; registrationDate?: string; active: boolean;
}
export interface Movement {
  id: number; product: Product; type: 'ENTRADA' | 'SALIDA'; quantity: number;
  dateTime: string; note: string; registeredBy: string;
}
