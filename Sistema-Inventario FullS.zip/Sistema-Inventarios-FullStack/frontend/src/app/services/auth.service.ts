import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { BehaviorSubject, tap } from 'rxjs';
import { UserSession } from '../models/inventory.models';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly userKey = 'inventory_user';
  private readonly credentialsKey = 'inventory_credentials';
  private userSubject = new BehaviorSubject<UserSession | null>(this.readUser());
  user$ = this.userSubject.asObservable();

  constructor(private http: HttpClient) {}

  login(username: string, password: string) {
    const credentials = btoa(`${username}:${password}`);
    const headers = new HttpHeaders({ Authorization: `Basic ${credentials}` });
    return this.http.post<UserSession>('/api/auth/login', {}, { headers }).pipe(
      tap(user => {
        sessionStorage.setItem(this.userKey, JSON.stringify(user));
        sessionStorage.setItem(this.credentialsKey, credentials);
        this.userSubject.next(user);
      })
    );
  }

  logout() {
    sessionStorage.clear();
    this.userSubject.next(null);
  }

  get user() { return this.userSubject.value; }
  get credentials() { return sessionStorage.getItem(this.credentialsKey); }
  get isLoggedIn() { return !!this.user; }
  get isAdmin() { return this.user?.role === 'ADMINISTRADOR'; }

  private readUser(): UserSession | null {
    const value = sessionStorage.getItem(this.userKey);
    return value ? JSON.parse(value) : null;
  }
}
