import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { AuthService } from './auth.service';

export const authInterceptor: HttpInterceptorFn = (request, next) => {
  const credentials = inject(AuthService).credentials;
  return next(credentials
    ? request.clone({ setHeaders: { Authorization: `Basic ${credentials}` } })
    : request);
};
