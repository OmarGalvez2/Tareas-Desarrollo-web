import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Category, Movement, Product } from '../models/inventory.models';

@Injectable({ providedIn: 'root' })
export class InventoryService {
  constructor(private http: HttpClient) {}

  getProducts(search = '', categoryId?: number, lowStock = false) {
    let params = new HttpParams().set('search', search).set('lowStock', lowStock);
    if (categoryId) params = params.set('categoryId', categoryId);
    return this.http.get<Product[]>('/api/products', { params });
  }
  getProduct(id: number) { return this.http.get<Product>(`/api/products/${id}`); }
  saveProduct(product: Product) {
    return product.id
      ? this.http.put<Product>(`/api/products/${product.id}`, product)
      : this.http.post<Product>('/api/products', product);
  }
  deactivateProduct(id: number) { return this.http.delete<void>(`/api/products/${id}`); }

  getCategories() { return this.http.get<Category[]>('/api/categories'); }
  saveCategory(category: Category) {
    return category.id
      ? this.http.put<Category>(`/api/categories/${category.id}`, category)
      : this.http.post<Category>('/api/categories', category);
  }
  deleteCategory(id: number) { return this.http.delete<void>(`/api/categories/${id}`); }

  getMovements() { return this.http.get<Movement[]>('/api/movements'); }
  registerMovement(data: { productId: number; type: string; quantity: number; note: string }) {
    return this.http.post<Movement>('/api/movements', data);
  }
}
