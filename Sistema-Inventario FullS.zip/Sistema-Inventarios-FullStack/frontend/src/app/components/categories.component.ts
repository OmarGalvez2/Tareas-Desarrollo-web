import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { InventoryService } from '../services/inventory.service';
import { Category } from '../models/inventory.models';

@Component({
  standalone: true,
  imports: [FormsModule],
  template: `
    <header class="page-header"><div><p class="eyebrow">Clasificación</p><h1>Categorías</h1><p>Organiza los productos del inventario.</p></div></header>
    <div class="two-columns">
      <section class="panel form-panel">
        <h2>{{ form.id ? 'Editar categoría' : 'Nueva categoría' }}</h2>
        <form (ngSubmit)="save()">
          <label>Nombre *<input [(ngModel)]="form.name" name="name" required></label>
          <label>Descripción<textarea [(ngModel)]="form.description" name="description"></textarea></label>
          @if (error) { <div class="alert error">{{ error }}</div> }
          <div class="form-actions"><button type="button" class="btn secondary" (click)="reset()">Limpiar</button>
            <button class="btn primary">Guardar</button></div>
        </form>
      </section>
      <section class="panel">
        <div class="category-list">
          @for (category of categories; track category.id) {
            <div><div><b>{{ category.name }}</b><small>{{ category.description || 'Sin descripción' }}</small></div>
              <span><button class="link-button" (click)="edit(category)">Editar</button>
              <button class="link-button danger-text" (click)="remove(category)">Eliminar</button></span></div>
          }
        </div>
      </section>
    </div>
  `
})
export class CategoriesComponent implements OnInit {
  categories: Category[] = [];
  form: Category = { name: '', description: '' };
  error = '';
  constructor(private inventory: InventoryService) {}
  ngOnInit() { this.load(); }
  load() { this.inventory.getCategories().subscribe(v => this.categories = v); }
  edit(category: Category) { this.form = { ...category }; }
  reset() { this.form = { name: '', description: '' }; this.error = ''; }
  save() {
    this.inventory.saveCategory(this.form).subscribe({
      next: () => { this.reset(); this.load(); },
      error: error => this.error = error.error?.message || 'No se pudo guardar'
    });
  }
  remove(category: Category) {
    if (category.id && confirm(`¿Eliminar ${category.name}?`))
      this.inventory.deleteCategory(category.id).subscribe({
        next: () => this.load(),
        error: error => this.error = error.error?.message || 'No se pudo eliminar'
      });
  }
}
