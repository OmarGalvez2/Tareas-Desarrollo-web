import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

@Component({
  standalone: true,
  imports: [FormsModule],
  template: `
    <main class="login-page">
      <section class="login-card">
        <div class="brand-mark">SI</div>
        <p class="eyebrow">Control de existencias</p>
        <h1>Sistema de Inventarios</h1>
        <p class="muted">Ingresa tus credenciales para continuar.</p>
        <form (ngSubmit)="submit()">
          <label>Usuario</label>
          <input [(ngModel)]="username" name="username" required autocomplete="username">
          <label>Contraseña</label>
          <input [(ngModel)]="password" name="password" type="password" required autocomplete="current-password">
          @if (error) { <div class="alert error">{{ error }}</div> }
          <button class="btn primary full" [disabled]="loading">{{ loading ? 'Ingresando...' : 'Iniciar sesión' }}</button>
        </form>
        <div class="demo-users">
          <strong>Usuarios de prueba</strong>
          <span>Administrador: admin / admin123</span>
          <span>Empleado: empleado / empleado123</span>
        </div>
      </section>
    </main>
  `
})
export class LoginComponent {
  username = 'admin';
  password = 'admin123';
  error = '';
  loading = false;

  constructor(private auth: AuthService, private router: Router) {
    if (auth.isLoggedIn) router.navigate(['/inicio']);
  }

  submit() {
    this.loading = true;
    this.error = '';
    this.auth.login(this.username, this.password).subscribe({
      next: () => this.router.navigate(['/inicio']),
      error: () => { this.error = 'Usuario o contraseña incorrectos'; this.loading = false; }
    });
  }
}
