import { Component } from '@angular/core';
import { Router, RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { AuthService } from '../services/auth.service';

@Component({
  standalone: true,
  imports: [RouterOutlet, RouterLink, RouterLinkActive],
  template: `
    <div class="app-shell">
      <aside class="sidebar">
        <div class="brand"><span class="brand-mark small">SI</span><div><b>Inventario</b><small>Control de stock</small></div></div>
        <nav>
          <a routerLink="/inicio" routerLinkActive="active">⌂ <span>Inicio</span></a>
          <a routerLink="/productos" routerLinkActive="active">□ <span>Productos</span></a>
          @if (auth.isAdmin) { <a routerLink="/categorias" routerLinkActive="active">◇ <span>Categorías</span></a> }
          <a routerLink="/movimientos" routerLinkActive="active">⇄ <span>Movimientos</span></a>
        </nav>
        <div class="user-box">
          <span class="avatar">{{ auth.user?.username?.charAt(0)?.toUpperCase() }}</span>
          <div><b>{{ auth.user?.username }}</b><small>{{ auth.isAdmin ? 'Administrador' : 'Empleado' }}</small></div>
        </div>
        <button class="logout" (click)="logout()">Cerrar sesión</button>
      </aside>
      <main class="main-content"><router-outlet /></main>
    </div>
  `
})
export class LayoutComponent {
  constructor(public auth: AuthService, private router: Router) {}
  logout() { this.auth.logout(); this.router.navigate(['/login']); }
}
