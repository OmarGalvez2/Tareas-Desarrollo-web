import { Component, OnInit } from '@angular/core';
import { DatePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { InventoryService } from '../services/inventory.service';
import { Movement, Product } from '../models/inventory.models';

@Component({
  standalone: true,
  imports: [FormsModule, DatePipe],
  template: `
    <header class="page-header"><div><p class="eyebrow">Entradas y salidas</p><h1>Movimientos</h1><p>Actualiza las cantidades disponibles.</p></div></header>
    <div class="two-columns movement-layout">
      <section class="panel form-panel">
        <h2>Registrar movimiento</h2>
        <form (ngSubmit)="save()" #form="ngForm">
          <label>Producto *<select [(ngModel)]="productId" name="product" required>
            <option [ngValue]="undefined">Selecciona</option>
            @for (product of products; track product.id) { <option [ngValue]="product.id">{{ product.code }} · {{ product.name }} ({{ product.quantity }})</option> }
          </select></label>
          <label>Tipo *<select [(ngModel)]="type" name="type"><option value="ENTRADA">Entrada</option><option value="SALIDA">Salida</option></select></label>
          <label>Cantidad *<input type="number" min="1" [(ngModel)]="quantity" name="quantity" required></label>
          <label>Nota<textarea [(ngModel)]="note" name="note" placeholder="Motivo o referencia"></textarea></label>
          @if (message) { <div class="alert success">{{ message }}</div> }
          @if (error) { <div class="alert error">{{ error }}</div> }
          <button class="btn primary full" [disabled]="form.invalid">Registrar movimiento</button>
        </form>
      </section>
      <section class="panel">
        <div class="panel-head"><div><h2>Historial reciente</h2><p>Últimas operaciones registradas.</p></div></div>
        <div class="movement-list">
          @for (movement of movements; track movement.id) {
            <div><span class="movement-type" [class.out]="movement.type === 'SALIDA'">{{ movement.type === 'ENTRADA' ? '+' : '-' }}{{ movement.quantity }}</span>
              <div><b>{{ movement.product.name }}</b><small>{{ movement.registeredBy }} · {{ movement.dateTime | date:'dd/MM/yyyy HH:mm' }}</small></div></div>
          } @empty { <p class="empty">Todavía no hay movimientos.</p> }
        </div>
      </section>
    </div>
  `
})
export class MovementsComponent implements OnInit {
  products: Product[] = [];
  movements: Movement[] = [];
  productId?: number;
  type = 'ENTRADA';
  quantity = 1;
  note = '';
  error = '';
  message = '';
  constructor(private inventory: InventoryService) {}
  ngOnInit() { this.load(); }
  load() {
    this.inventory.getProducts().subscribe(v => this.products = v.filter(p => p.active));
    this.inventory.getMovements().subscribe(v => this.movements = v);
  }
  save() {
    if (!this.productId) return;
    this.error = ''; this.message = '';
    this.inventory.registerMovement({ productId: this.productId, type: this.type, quantity: this.quantity, note: this.note }).subscribe({
      next: () => { this.message = 'Movimiento registrado correctamente'; this.quantity = 1; this.note = ''; this.load(); },
      error: error => this.error = error.error?.message || 'No se pudo registrar'
    });
  }
}
