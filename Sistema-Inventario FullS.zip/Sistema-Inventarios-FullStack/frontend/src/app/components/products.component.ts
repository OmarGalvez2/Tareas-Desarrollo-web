import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { InventoryService } from '../services/inventory.service';
import { Category, Product } from '../models/inventory.models';

@Component({
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
    <header class="page-header">
      <div><p class="eyebrow">Catálogo</p><h1>Productos</h1><p>Consulta y controla las existencias.</p></div>
      @if (auth.isAdmin) { <a routerLink="/productos/nuevo" class="btn primary">+ Nuevo producto</a> }
    </header>
    @if (message) { <div class="alert success">{{ message }}</div> }
    <section class="filters">
      <input [(ngModel)]="search" (input)="load()" placeholder="Buscar por nombre o código">
      <select [(ngModel)]="categoryId" (change)="load()">
        <option [ngValue]="undefined">Todas las categorías</option>
        @for (category of categories; track category.id) { <option [ngValue]="category.id">{{ category.name }}</option> }
      </select>
      <label class="check"><input type="checkbox" [(ngModel)]="lowStock" (change)="load()"> Poco inventario</label>
    </section>
    <section class="product-grid">
      @for (product of products; track product.id) {
        <article class="product-card">
          <div class="card-top"><span class="product-code">{{ product.code }}</span>
            <span class="status" [class.inactive]="!product.active">{{ product.active ? 'Activo' : 'Inactivo' }}</span></div>
          <h2>{{ product.name }}</h2><p>{{ product.category.name }} · {{ product.supplier }}</p>
          <div class="stock-row"><div><small>Disponible</small><strong [class.low]="product.quantity <= product.minimumStock">{{ product.quantity }}</strong></div>
            <div><small>Stock mínimo</small><strong>{{ product.minimumStock }}</strong></div></div>
          <dl><div><dt>Compra</dt><dd>{{ product.purchasePrice | number:'1.2-2' }}</dd></div>
              <div><dt>Venta</dt><dd>{{ product.salePrice | number:'1.2-2' }}</dd></div></dl>
          <div class="card-actions">
            @if (auth.isAdmin) {
              <a [routerLink]="['/productos/editar', product.id]" class="btn secondary">Editar</a>
              @if (product.active) { <button class="btn danger" (click)="deactivate(product)">Desactivar</button> }
            } @else {
              <a routerLink="/movimientos" class="btn secondary">Registrar movimiento</a>
            }
          </div>
        </article>
      } @empty { <div class="panel empty">No se encontraron productos.</div> }
    </section>
  `
})
export class ProductsComponent implements OnInit {
  products: Product[] = [];
  categories: Category[] = [];
  search = '';
  categoryId?: number;
  lowStock = false;
  message = '';
  constructor(public auth: AuthService, private inventory: InventoryService) {}
  ngOnInit() { this.inventory.getCategories().subscribe(v => this.categories = v); this.load(); }
  load() { this.inventory.getProducts(this.search, this.categoryId, this.lowStock).subscribe(v => this.products = v); }
  deactivate(product: Product) {
    if (product.id && confirm(`¿Desactivar ${product.name}?`))
      this.inventory.deactivateProduct(product.id).subscribe(() => { this.message = 'Producto desactivado'; this.load(); });
  }
}
