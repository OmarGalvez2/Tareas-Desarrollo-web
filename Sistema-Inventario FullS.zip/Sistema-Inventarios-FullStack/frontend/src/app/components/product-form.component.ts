import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, ActivatedRoute, RouterLink } from '@angular/router';
import { InventoryService } from '../services/inventory.service';
import { Category, Product } from '../models/inventory.models';

@Component({
  standalone: true,
  imports: [FormsModule, RouterLink],
  template: `
    <a routerLink="/productos" class="back">← Volver a productos</a>
    <header class="page-header compact"><div><p class="eyebrow">Información del producto</p><h1>{{ product.id ? 'Editar producto' : 'Nuevo producto' }}</h1></div></header>
    <section class="panel form-panel">
      <form (ngSubmit)="save()" #form="ngForm">
        <div class="form-grid">
          <label>Código *<input [(ngModel)]="product.code" name="code" required></label>
          <label>Nombre *<input [(ngModel)]="product.name" name="name" required></label>
          <label class="span-2">Descripción<textarea [(ngModel)]="product.description" name="description"></textarea></label>
          <label>Categoría *<select [(ngModel)]="product.category.id" name="category" required>
            <option [ngValue]="undefined">Selecciona</option>
            @for (category of categories; track category.id) { <option [ngValue]="category.id">{{ category.name }}</option> }
          </select></label>
          <label>Proveedor *<input [(ngModel)]="product.supplier" name="supplier" required></label>
          <label>Precio de compra *<input type="number" min="0" step="0.01" [(ngModel)]="product.purchasePrice" name="purchase" required></label>
          <label>Precio de venta *<input type="number" min="0" step="0.01" [(ngModel)]="product.salePrice" name="sale" required></label>
          <label>Cantidad disponible *<input type="number" min="0" [(ngModel)]="product.quantity" name="quantity" required></label>
          <label>Stock mínimo *<input type="number" min="0" [(ngModel)]="product.minimumStock" name="minimum" required></label>
          <label class="check"><input type="checkbox" [(ngModel)]="product.active" name="active"> Producto activo</label>
        </div>
        @if (error) { <div class="alert error">{{ error }}</div> }
        <div class="form-actions"><a routerLink="/productos" class="btn secondary">Cancelar</a>
          <button class="btn primary" [disabled]="form.invalid">Guardar producto</button></div>
      </form>
    </section>
  `
})
export class ProductFormComponent implements OnInit {
  categories: Category[] = [];
  error = '';
  product: Product = {
    code: '', name: '', description: '', category: { name: '', description: '' },
    purchasePrice: 0, salePrice: 0, quantity: 0, minimumStock: 0, supplier: '', active: true
  };
  constructor(private inventory: InventoryService, private route: ActivatedRoute, private router: Router) {}
  ngOnInit() {
    this.inventory.getCategories().subscribe(v => this.categories = v);
    const id = Number(this.route.snapshot.paramMap.get('id'));
    if (id) this.inventory.getProduct(id).subscribe(v => this.product = v);
  }
  save() {
    this.error = '';
    this.inventory.saveProduct(this.product).subscribe({
      next: () => this.router.navigate(['/productos']),
      error: error => this.error = error.error?.message || 'No se pudo guardar'
    });
  }
}
