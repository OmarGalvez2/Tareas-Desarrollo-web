import { Component, OnInit } from '@angular/core';
import { DecimalPipe } from '@angular/common';
import { RouterLink } from '@angular/router';
import { forkJoin } from 'rxjs';
import { InventoryService } from '../services/inventory.service';
import { Product } from '../models/inventory.models';

@Component({
  standalone: true,
  imports: [DecimalPipe, RouterLink],
  template: `
    <header class="page-header"><div><p class="eyebrow">Resumen general</p><h1>Inicio</h1><p>Estado actual del inventario.</p></div></header>
    <section class="stats-grid">
      <article class="stat-card"><span>Productos</span><strong>{{ products.length }}</strong><small>Registros totales</small></article>
      <article class="stat-card"><span>Poco inventario</span><strong>{{ lowStock }}</strong><small>Requieren atención</small></article>
      <article class="stat-card"><span>Categorías</span><strong>{{ categoryCount }}</strong><small>Grupos registrados</small></article>
      <article class="stat-card"><span>Valor de compra</span><strong>{{ inventoryValue | number:'1.2-2' }}</strong><small>Inventario disponible</small></article>
    </section>
    <section class="panel">
      <div class="panel-head"><div><h2>Productos con poco stock</h2><p>Cantidad igual o menor al mínimo.</p></div><a routerLink="/productos" class="btn secondary">Ver productos</a></div>
      <div class="simple-list">
        @for (product of lowProducts; track product.id) {
          <div><span class="product-code">{{ product.code }}</span><b>{{ product.name }}</b><span>{{ product.quantity }} / mín. {{ product.minimumStock }}</span></div>
        } @empty { <p class="empty">No hay productos con poco inventario.</p> }
      </div>
    </section>
  `
})
export class DashboardComponent implements OnInit {
  products: Product[] = [];
  categoryCount = 0;
  lowStock = 0;
  inventoryValue = 0;
  lowProducts: Product[] = [];
  constructor(private inventory: InventoryService) {}
  ngOnInit() {
    forkJoin([this.inventory.getProducts(), this.inventory.getCategories()]).subscribe(([products, categories]) => {
      this.products = products;
      this.categoryCount = categories.length;
      this.lowProducts = products.filter(p => p.active && p.quantity <= p.minimumStock);
      this.lowStock = this.lowProducts.length;
      this.inventoryValue = products.reduce((sum, p) => sum + p.purchasePrice * p.quantity, 0);
    });
  }
}
