@echo off
title Sistema de Inventarios
cd /d "%~dp0"
echo Iniciando backend y frontend...
start "Inventario Backend" cmd /k "cd /d ""%~dp0backend"" && mvnw.cmd spring-boot:run"
timeout /t 6 /nobreak >nul
start "Inventario Frontend" cmd /k "cd /d ""%~dp0frontend"" && INICIAR_FRONTEND.bat"
timeout /t 10 /nobreak >nul
start "" http://localhost:4200
