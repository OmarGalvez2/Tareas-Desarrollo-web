package com.ejemplo.inventario.dto;

public record LoginResponse(String username, String role) {}
