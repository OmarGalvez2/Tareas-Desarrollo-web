package com.ejemplo.inventario.controller;

import com.ejemplo.inventario.model.*;
import com.ejemplo.inventario.repository.*;
import jakarta.validation.Valid;
import org.springframework.data.domain.Sort;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/api/products")
public class ProductController {
    private final ProductRepository products;
    private final CategoryRepository categories;

    public ProductController(ProductRepository products, CategoryRepository categories) {
        this.products = products;
        this.categories = categories;
    }

    @GetMapping
    public List<Product> list(@RequestParam(defaultValue = "") String search,
                              @RequestParam(required = false) Long categoryId,
                              @RequestParam(defaultValue = "false") boolean lowStock) {
        String term = search.toLowerCase().trim();
        return products.findAll(Sort.by("name")).stream()
                .filter(p -> term.isEmpty() || p.getName().toLowerCase().contains(term)
                        || p.getCode().toLowerCase().contains(term))
                .filter(p -> categoryId == null || p.getCategory().getId().equals(categoryId))
                .filter(p -> !lowStock || p.getQuantity() <= p.getMinimumStock())
                .toList();
    }

    @GetMapping("/{id}")
    public Product get(@PathVariable Long id) {
        return products.findById(id).orElseThrow(() -> new IllegalArgumentException("El producto no existe"));
    }

    @PostMapping
    @PreAuthorize("hasRole('ADMINISTRADOR')")
    public Product create(@Valid @RequestBody Product product) {
        if (products.existsByCodeIgnoreCase(product.getCode()))
            throw new IllegalArgumentException("Ya existe un producto con ese código");
        product.setId(null);
        product.setCategory(findCategory(product));
        return products.save(product);
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ADMINISTRADOR')")
    public Product update(@PathVariable Long id, @Valid @RequestBody Product data) {
        Product product = products.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("El producto no existe"));
        product.setCode(data.getCode()); product.setName(data.getName());
        product.setDescription(data.getDescription()); product.setCategory(findCategory(data));
        product.setPurchasePrice(data.getPurchasePrice()); product.setSalePrice(data.getSalePrice());
        product.setQuantity(data.getQuantity()); product.setMinimumStock(data.getMinimumStock());
        product.setSupplier(data.getSupplier()); product.setActive(data.isActive());
        return products.save(product);
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMINISTRADOR')")
    public void deactivate(@PathVariable Long id) {
        Product product = products.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("El producto no existe"));
        product.setActive(false);
        products.save(product);
    }

    private Category findCategory(Product product) {
        if (product.getCategory() == null || product.getCategory().getId() == null)
            throw new IllegalArgumentException("Selecciona una categoría");
        return categories.findById(product.getCategory().getId())
                .orElseThrow(() -> new IllegalArgumentException("La categoría no existe"));
    }
}
