package com.ejemplo.inventario.repository;

import com.ejemplo.inventario.model.InventoryMovement;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface MovementRepository extends JpaRepository<InventoryMovement, Long> {
    List<InventoryMovement> findAllByOrderByDateTimeDesc();
}
