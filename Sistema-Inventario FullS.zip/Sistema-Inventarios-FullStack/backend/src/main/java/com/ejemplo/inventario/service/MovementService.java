package com.ejemplo.inventario.service;

import com.ejemplo.inventario.dto.MovementRequest;
import com.ejemplo.inventario.model.*;
import com.ejemplo.inventario.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDateTime;

@Service
public class MovementService {
    private final ProductRepository products;
    private final MovementRepository movements;

    public MovementService(ProductRepository products, MovementRepository movements) {
        this.products = products;
        this.movements = movements;
    }

    @Transactional
    public InventoryMovement register(MovementRequest request, String username) {
        Product product = products.findById(request.productId())
                .orElseThrow(() -> new IllegalArgumentException("El producto no existe"));
        if (!product.isActive()) throw new IllegalArgumentException("El producto está inactivo");

        int newQuantity = request.type() == MovementType.ENTRADA
                ? product.getQuantity() + request.quantity()
                : product.getQuantity() - request.quantity();
        if (newQuantity < 0) throw new IllegalArgumentException("No hay stock suficiente");

        product.setQuantity(newQuantity);
        products.save(product);

        InventoryMovement movement = new InventoryMovement();
        movement.setProduct(product);
        movement.setType(request.type());
        movement.setQuantity(request.quantity());
        movement.setNote(request.note());
        movement.setDateTime(LocalDateTime.now());
        movement.setRegisteredBy(username);
        return movements.save(movement);
    }
}
