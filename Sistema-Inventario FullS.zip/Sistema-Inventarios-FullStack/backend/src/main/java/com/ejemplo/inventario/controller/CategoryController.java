package com.ejemplo.inventario.controller;

import com.ejemplo.inventario.model.Category;
import com.ejemplo.inventario.repository.*;
import jakarta.validation.Valid;
import org.springframework.data.domain.Sort;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/categories")
public class CategoryController {
    private final CategoryRepository categories;
    private final ProductRepository products;

    public CategoryController(CategoryRepository categories, ProductRepository products) {
        this.categories = categories;
        this.products = products;
    }

    @GetMapping
    public List<Category> list() {
        return categories.findAll(Sort.by("name"));
    }

    @PostMapping
    @PreAuthorize("hasRole('ADMINISTRADOR')")
    public Category create(@Valid @RequestBody Category category) {
        if (categories.existsByNameIgnoreCase(category.getName()))
            throw new IllegalArgumentException("La categoría ya existe");
        category.setId(null);
        return categories.save(category);
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ADMINISTRADOR')")
    public Category update(@PathVariable Long id, @Valid @RequestBody Category data) {
        Category category = categories.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("La categoría no existe"));
        category.setName(data.getName());
        category.setDescription(data.getDescription());
        return categories.save(category);
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMINISTRADOR')")
    public void delete(@PathVariable Long id) {
        if (products.existsByCategoryId(id))
            throw new IllegalArgumentException("No se puede eliminar: tiene productos asociados");
        categories.deleteById(id);
    }
}
