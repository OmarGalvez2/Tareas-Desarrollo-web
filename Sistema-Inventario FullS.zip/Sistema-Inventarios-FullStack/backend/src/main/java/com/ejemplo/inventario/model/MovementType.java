package com.ejemplo.inventario.model;

public enum MovementType {
    ENTRADA, SALIDA
}
