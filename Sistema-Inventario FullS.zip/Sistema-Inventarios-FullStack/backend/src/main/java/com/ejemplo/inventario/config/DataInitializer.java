package com.ejemplo.inventario.config;

import com.ejemplo.inventario.model.*;
import com.ejemplo.inventario.repository.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;
import java.math.BigDecimal;

@Configuration
public class DataInitializer {
    @Bean
    CommandLineRunner initialData(UserRepository users, CategoryRepository categories,
                                  ProductRepository products, PasswordEncoder encoder) {
        return args -> {
            if (users.count() == 0) {
                users.save(user("admin", "admin123", Role.ADMINISTRADOR, encoder));
                users.save(user("empleado", "empleado123", Role.EMPLEADO, encoder));
            }
            if (categories.count() == 0) {
                Category electronics = categories.save(category("Electrónicos", "Equipos y accesorios"));
                Category food = categories.save(category("Alimentos", "Productos alimenticios"));
                categories.save(category("Herramientas", "Herramientas de trabajo"));
                categories.save(category("Limpieza", "Productos de limpieza"));
                products.save(product("ELE-001", "Teclado USB", electronics, "TecnoMax",
                        new BigDecimal("80"), new BigDecimal("120"), 12, 5));
                products.save(product("ALI-001", "Arroz 1 kg", food, "Distribuidora Central",
                        new BigDecimal("8"), new BigDecimal("11"), 4, 10));
            }
        };
    }

    private AppUser user(String name, String password, Role role, PasswordEncoder encoder) {
        AppUser user = new AppUser();
        user.setUsername(name); user.setPassword(encoder.encode(password)); user.setRole(role);
        return user;
    }

    private Category category(String name, String description) {
        Category category = new Category();
        category.setName(name); category.setDescription(description);
        return category;
    }

    private Product product(String code, String name, Category category, String supplier,
                            BigDecimal purchase, BigDecimal sale, int quantity, int minimum) {
        Product product = new Product();
        product.setCode(code); product.setName(name); product.setDescription("Producto de ejemplo");
        product.setCategory(category); product.setSupplier(supplier);
        product.setPurchasePrice(purchase); product.setSalePrice(sale);
        product.setQuantity(quantity); product.setMinimumStock(minimum);
        return product;
    }
}
