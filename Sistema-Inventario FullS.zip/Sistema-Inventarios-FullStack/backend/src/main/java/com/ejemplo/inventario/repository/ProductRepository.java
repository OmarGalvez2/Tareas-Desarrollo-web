package com.ejemplo.inventario.repository;

import com.ejemplo.inventario.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductRepository extends JpaRepository<Product, Long> {
    boolean existsByCodeIgnoreCase(String code);
    boolean existsByCategoryId(Long categoryId);
}
