package com.ejemplo.inventario.controller;

import com.ejemplo.inventario.dto.MovementRequest;
import com.ejemplo.inventario.model.InventoryMovement;
import com.ejemplo.inventario.repository.MovementRepository;
import com.ejemplo.inventario.service.MovementService;
import jakarta.validation.Valid;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/movements")
public class MovementController {
    private final MovementRepository movements;
    private final MovementService service;

    public MovementController(MovementRepository movements, MovementService service) {
        this.movements = movements;
        this.service = service;
    }

    @GetMapping
    public List<InventoryMovement> list() {
        return movements.findAllByOrderByDateTimeDesc();
    }

    @PostMapping
    public InventoryMovement register(@Valid @RequestBody MovementRequest request, Authentication authentication) {
        return service.register(request, authentication.getName());
    }
}
