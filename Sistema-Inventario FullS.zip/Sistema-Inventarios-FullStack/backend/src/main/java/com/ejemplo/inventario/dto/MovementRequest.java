package com.ejemplo.inventario.dto;

import com.ejemplo.inventario.model.MovementType;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

public record MovementRequest(
        @NotNull Long productId,
        @NotNull MovementType type,
        @Min(1) int quantity,
        String note
) {}
