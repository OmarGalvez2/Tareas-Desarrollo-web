package com.ejemplo.inventario.model;

public enum Role {
    ADMINISTRADOR, EMPLEADO
}
