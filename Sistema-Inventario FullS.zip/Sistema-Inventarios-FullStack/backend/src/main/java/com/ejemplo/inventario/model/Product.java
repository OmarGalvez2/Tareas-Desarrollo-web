package com.ejemplo.inventario.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
public class Product {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @NotBlank(message = "El código es obligatorio")
    @Column(unique = true)
    private String code;
    @NotBlank(message = "El nombre es obligatorio")
    private String name;
    @Size(max = 500)
    private String description;
    @ManyToOne(optional = false)
    private Category category;
    @NotNull @DecimalMin("0.0")
    private BigDecimal purchasePrice;
    @NotNull @DecimalMin("0.0")
    private BigDecimal salePrice;
    @Min(0)
    private int quantity;
    @Min(0)
    private int minimumStock;
    @NotBlank(message = "El proveedor es obligatorio")
    private String supplier;
    private LocalDate registrationDate;
    private boolean active = true;

    @PrePersist
    void beforeInsert() {
        if (registrationDate == null) registrationDate = LocalDate.now();
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public Category getCategory() { return category; }
    public void setCategory(Category category) { this.category = category; }
    public BigDecimal getPurchasePrice() { return purchasePrice; }
    public void setPurchasePrice(BigDecimal purchasePrice) { this.purchasePrice = purchasePrice; }
    public BigDecimal getSalePrice() { return salePrice; }
    public void setSalePrice(BigDecimal salePrice) { this.salePrice = salePrice; }
    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }
    public int getMinimumStock() { return minimumStock; }
    public void setMinimumStock(int minimumStock) { this.minimumStock = minimumStock; }
    public String getSupplier() { return supplier; }
    public void setSupplier(String supplier) { this.supplier = supplier; }
    public LocalDate getRegistrationDate() { return registrationDate; }
    public void setRegistrationDate(LocalDate registrationDate) { this.registrationDate = registrationDate; }
    public boolean isActive() { return active; }
    public void setActive(boolean active) { this.active = active; }
}
