@echo off
set "MAVEN_LOCAL=%~dp0.mvn\apache-maven-3.9.9"
call "%MAVEN_LOCAL%\bin\mvn.cmd" %*
